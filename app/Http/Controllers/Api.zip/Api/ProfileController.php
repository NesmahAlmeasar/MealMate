<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Client;
use App\Models\BodyData;
use App\Models\Lifestyle;
use App\Models\Location;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Facades\Auth;

class ProfileController extends Controller
{
    /**
     * GET /api/profile
     * عرض الملف الشخصي الكامل
     */
    public function show(Request $request)
    {
        // جلب المستخدم الحالي
        $user = $request->user();
        
        // جلب بيانات Client
        $client = Client::where('clients_id', $user->user_id)
            ->with([
                'bodyData',
                'lifestyle',
                'chronicDiseases',
                'allergies',
                'medicalRecords',
                'diet',
                'locations'
            ])
            ->first();
        
        if (!$client) {
            return response()->json([
                'status' => 'error',
                'message' => 'بيانات العميل غير موجودة'
            ], 404);
        }
        
        // تجهيز البيانات
        return response()->json([
            'status' => 'success',
            'data' => [
                'personal_info' => [
                    'first_name' => $user->Fname,
                    'last_name' => $user->Lname,
                    'email' => $user->email,
                    'phone' => $user->phone,
                    'photo_url' => $user->photo_url ? asset('storage/' . $user->photo_url) : null,
                ],
                'location' => $client->locations->first() ? [
                    'latitude' => $client->locations->first()->latitude_x,
                    'longitude' => $client->locations->first()->longitude_y,
                    'description' => $client->locations->first()->description,
                ] : null,
                'body_data' => $client->bodyData ? [
                    'birth_date' => $client->bodyData->birth_date,
                    'height_cm' => $client->bodyData->height_cm,
                    'weight_kg' => $client->bodyData->weight_kg,
                    'sex' => $client->bodyData->sex,
                    'bmi' => $this->calculateBMI($client->bodyData->weight_kg, $client->bodyData->height_cm),
                ] : null,
                'lifestyle' => $client->lifestyle ? [
                    'smoking' => $client->lifestyle->smoking,
                    'activity_level' => $client->lifestyle->activity_level,
                    'sleeping_hours' => $client->lifestyle->sleeping_hours,
                ] : null,
                'health_info' => [
                    'chronic_diseases' => $client->chronicDiseases->map(fn($d) => [
                        'id' => $d->chronic_diseases_id,
                        'name' => $d->chronic_diseases
                    ]),
                    'allergies' => $client->allergies->map(fn($a) => [
                        'id' => $a->allergy_id,
                        'name' => $a->name
                    ]),
                    'medical_records' => $client->medicalRecords->map(fn($m) => [
                        'id' => $m->medical_record_id,
                        'description' => $m->medical_record,
                        'created_at' => $m->created_at
                    ])
                ],
                'current_diet' => $client->diet ? [
                    'id' => $client->diet->diets_id,
                    'name' => $client->diet->name,
                    'description' => $client->diet->description,
                    'is_public' => $client->diet->is_public
                ] : null,
                'completion_status' => $this->checkCompletion($client)
            ]
        ]);
    }
    
    /**
     * PUT /api/profile
     * تحديث الملف الشخصي
     */
    public function update(Request $request)
    {
        $user = $request->user();
        $client = Client::where('clients_id', $user->user_id)->first();
        
        if (!$client) {
            return response()->json([
                'status' => 'error',
                'message' => 'بيانات العميل غير موجودة'
            ], 404);
        }
        
        // Validation
        $validator = Validator::make($request->all(), [
            // Personal Info
            'first_name' => 'sometimes|string|max:255',
            'last_name' => 'sometimes|string|max:255',
            'email' => 'sometimes|email|unique:users,email,' . $user->user_id . ',user_id',
            'phone' => 'sometimes|string|max:20',
            'photo' => 'sometimes|image|mimes:jpeg,png,jpg|max:2048',
            
            // Location
            'latitude' => 'sometimes|numeric|between:-90,90',
            'longitude' => 'sometimes|numeric|between:-180,180',
            'location_description' => 'sometimes|string|max:255',
            
            // Body Data
            'birth_date' => 'sometimes|date',
            'height_cm' => 'sometimes|numeric|min:50|max:300',
            'weight_kg' => 'sometimes|numeric|min:20|max:500',
            'sex' => 'sometimes|in:Male,Female',
            
            // Lifestyle
            'smoking' => 'sometimes|boolean',
            'activity_level' => 'sometimes|in:sedentary,lightly_active,moderately_active,very_active,extremely_active',
            'sleeping_hours' => 'sometimes|numeric|min:0|max:24',
            
            // Health Info
            'chronic_diseases' => 'sometimes|array',
            'chronic_diseases.*' => 'exists:chronic_diseases,chronic_diseases_id',
            'allergies' => 'sometimes|array',
            'allergies.*' => 'exists:allergies,allergy_id',
        ]);
        
        if ($validator->fails()) {
            return response()->json([
                'status' => 'error',
                'message' => 'بيانات غير صحيحة',
                'errors' => $validator->errors()
            ], 422);
        }
        
        // Update Personal Info
        if ($request->has('first_name')) $user->Fname = $request->first_name;
        if ($request->has('last_name')) $user->Lname = $request->last_name;
        if ($request->has('email')) $user->email = $request->email;
        if ($request->has('phone')) $user->phone = $request->phone;
        
        // Handle Photo Upload
        if ($request->hasFile('photo')) {
            if ($user->photo_url) {
                Storage::disk('public')->delete($user->photo_url);
            }
            $user->photo_url = $request->file('photo')->store('profile_photos', 'public');
        }
        
        $user->save();
        
        // Update Body Data
        if ($request->hasAny(['birth_date', 'height_cm', 'weight_kg', 'sex'])) {
            BodyData::updateOrCreate(
                ['clients_id' => $client->clients_id],
                array_filter([
                    'birth_date' => $request->birth_date,
                    'height_cm' => $request->height_cm,
                    'weight_kg' => $request->weight_kg,
                    'sex' => $request->sex,
                ])
            );
        }
        
        // Update Lifestyle
        if ($request->hasAny(['smoking', 'activity_level', 'sleeping_hours'])) {
            Lifestyle::updateOrCreate(
                ['clients_id' => $client->clients_id],
                array_filter([
                    'smoking' => $request->smoking,
                    'activity_level' => $request->activity_level,
                    'sleeping_hours' => $request->sleeping_hours,
                ])
            );
        }
        
        // Update Health Info
        if ($request->has('chronic_diseases')) {
            $client->chronicDiseases()->sync($request->chronic_diseases);
        }
        
        if ($request->has('allergies')) {
            $client->allergies()->sync($request->allergies);
        }
        
        // Update Location
        if ($request->hasAny(['latitude', 'longitude'])) {
            // حذف المواقع القديمة
            $client->locations()->detach();
            
            // إنشاء موقع جديد
            $location = Location::create([
                'latitude_x' => $request->latitude,
                'longitude_y' => $request->longitude,
                'description' => $request->location_description ?? null
            ]);
            
            // ربط الموقع بالعميل
            $client->locations()->attach($location->location_id);
        }
        
        // Check if profile is now complete
        $completionStatus = $this->checkCompletion($client);
        
        return response()->json([
            'status' => 'success',
            'message' => 'تم تحديث الملف الشخصي بنجاح',
            'profile_complete' => $completionStatus,
            'suggest_diet' => $completionStatus['is_complete'] ? 'هل تريد أن نقترح لك حمية باستخدام الذكاء الاصطناعي؟' : null
        ]);
    }
    
    /**
     * Helper: حساب BMI
     */
    private function calculateBMI($weight, $height)
    {
        if (!$weight || !$height) return null;
        $heightInMeters = $height / 100;
        return round($weight / ($heightInMeters * $heightInMeters), 2);
    }
    
    /**
     * Helper: فحص اكتمال البيانات
     */
    private function checkCompletion($client)
    {
        $hasBodyData = $client->bodyData !== null;
        $hasLifestyle = $client->lifestyle !== null;
        $hasHealthInfo = $client->chronicDiseases->count() > 0 || $client->allergies->count() > 0;
        
        return [
            'is_complete' => $hasBodyData && $hasLifestyle,
            'has_body_data' => $hasBodyData,
            'has_lifestyle' => $hasLifestyle,
            'has_health_info' => $hasHealthInfo
        ];
    }
}
