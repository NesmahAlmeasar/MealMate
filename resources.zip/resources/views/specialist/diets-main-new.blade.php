@extends('layouts.specialist_app')

{{-- 1. تحديد عنوان الصفحة --}}
@section('title', 'Diet Plans')

{{-- 2. إضافة الـ CSS المضمن (inline) الخاص بهذا التصميم الجديد --}}
@push('styles')
    {{-- ملاحظة: تم حذف <link href="New folder/styles.css"> لأنه يتعارض مع general.css --}}
    <style>
        .diets-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
        }
        .diets-title {
            font-size: 24px;
            font-weight: bold;
            color: var(--text-dark);
        }
        .back-button-link {
            display: inline-flex;
            align-items: center;
            gap: 5px;
            color: var(--text-light);
            text-decoration: none;
            font-size: 14px;
            transition: color 0.3s ease;
            margin-bottom: 15px;
        }
        .back-button-link:hover {
            color: var(--olive-dark);
        }
        .diets-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 25px;
        }
        .diet-card {
            background: white;
            border-radius: 10px;
            overflow: hidden;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            cursor: pointer;
            border: 1px solid var(--border-color);
        }
        .diet-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.12);
        }
        .diet-card-image {
            width: 100%;
            height: 180px;
            background: linear-gradient(135deg, var(--olive-light), var(--olive-medium));
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 60px;
            overflow: hidden;
        }
        .diet-card-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        .diet-card-content { padding: 15px; }
        .diet-card-title {
            font-size: 16px;
            font-weight: bold;
            color: var(--text-dark);
            margin-bottom: 8px;
        }
        .diet-card-description {
            font-size: 13px;
            color: var(--text-light);
            line-height: 1.5;
            margin-bottom: 12px;
        }
        .diet-card-footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding-top: 10px;
            border-top: 1px solid var(--border-color);
        }
        .diet-card-tag {
            display: inline-block;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 11px;
            font-weight: 600;
        }
        .diet-tag-public {
            background-color: #DBEAFE;
            color: var(--blue-primary);
        }
        .diet-tag-private {
            background-color: #FEE2E2;
            color: var(--red-accent);
        }
        .diet-card-actions { display: flex; gap: 8px; }
        .diet-action-btn {
            width: 30px;
            height: 30px;
            border-radius: 50%;
            border: none;
            background-color: var(--olive-very-light);
            cursor: pointer;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .diet-action-btn:hover { background-color: var(--olive-light); }
        .diet-action-btn.edit:hover {
            background-color: #DBEAFE;
            color: var(--blue-primary);
        }
        .diet-action-btn.delete:hover {
            background-color: #FEE2E2;
            color: var(--red-accent);
        }
        .add-diet-section {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 1px 3px rgba(0, 0, 0, 0.06);
            border: 1px solid var(--border-color);
            margin-bottom: 25px;
            text-align: center;
        }
        .add-diet-icon { font-size: 40px; margin-bottom: 10px; }
        .add-diet-text {
            font-size: 14px;
            color: var(--text-light);
            margin-bottom: 12px;
        }
        .btn-primary { /* تعريف الأزرار الأساسية */
            background-color: var(--olive-dark);
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 600;
            transition: background-color 0.3s ease;
        }
        .btn-primary:hover { background-color: #5a6d1f; }
        .btn-secondary { /* تعريف الأزرار الثانوية */
            background-color: #f3f4f6;
            color: #333;
            padding: 10px 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
            cursor: pointer;
        }
        /* (باقي كود الـ CSS المضمن) */
    </style>
@endpush


{{-- 3. هذا هو المحتوى المتغير --}}
@section('content')

  
    <div class="add-diet-section">
        <div class="add-diet-icon">➕</div>
        <div class="add-diet-text">Create a new diet plan for your clients</div>
        {{-- إصلاح رابط الزر --}}
        <button class="btn-secondary" onclick="window.location.href='{{ url('specialist/diets/add') }}';">
            <i class="fas fa-plus"></i> Create Diet Plan
        </button>
    </div>

    <div class="diets-grid" id="dietsGrid">
        <div class="diet-card" onclick="window.location.href='{{ url('specialist/diets/details/1') }}';">
            <div class="diet-card-image">🥩</div>
            <div class="diet-card-content">
                <div class="diet-card-title">Keto Diet</div>
                <div class="diet-card-description">
                    High-fat, low-carb diet for rapid weight loss
                </div>
                <div class="diet-card-footer">
                    <span class="diet-card-tag diet-tag-public">Public</span>
                    <div class="diet-card-actions" onclick="event.stopPropagation();">
                        <button class="diet-action-btn edit" title="Edit" onclick="window.location.href='{{ url('specialist/diets/edit/1') }}';">
                            ✏️
                        </button>
                        <button class="diet-action-btn delete" title="Delete" onclick="deleteDietConfirm(1);">
                            🗑️
                        </button>
                    </div>
                </div>
            </div>
        </div>

        <div class="diet-card" onclick="window.location.href='{{ url('specialist/diets/details/2') }}';">
            <div class="diet-card-image">🍞</div>
            <div class="diet-card-content">
                <div class="diet-card-title">Low-Carb Diet</div>
                <div class="diet-card-description">
                    Reduced carbohydrate intake for sustainable weight loss
                </div>
                <div class="diet-card-footer">
                    <span class="diet-card-tag diet-tag-public">Public</span>
                    <div class="diet-card-actions" onclick="event.stopPropagation();">
                        <button class="diet-action-btn edit" title="Edit" onclick="window.location.href='{{ url('specialist/diets/edit/2') }}';">
                            ✏️
                        </button>
                        <button class="diet-action-btn delete" title="Delete" onclick="deleteDietConfirm(2);">
                            🗑️
                        </button>
                    </div>
                </div>
            </div>
        </div>
        
        </div>
@endsection


{{-- 4. إضافة الـ JS المضمن الخاص بهذه الصفحة --}}
@push('scripts')
    <script>
        // دالة تأكيد الحذف
        function deleteDietConfirm(dietId) {
            // (نفترض أن لديك دوال showConfirmation و showNotification من ملف JS آخر)
            if (confirm('Are you sure you want to delete this diet plan?')) {
                console.log('Deleting diet ' + dietId);
                // (هنا تضع كود الحذف الفعلي)
                alert('Diet plan deleted successfully!');
                location.reload();
            }
        }

        // دالة البحث
        document.addEventListener('DOMContentLoaded', function() {
            const searchInput = document.getElementById('dietSearch');
            if (searchInput) {
                searchInput.addEventListener('input', function(e) {
                    const term = e.target.value.toLowerCase();
                    const cards = document.querySelectorAll('.diet-card');
                    cards.forEach(card => {
                        const title = card.querySelector('.diet-card-title').textContent.toLowerCase();
                        const description = card.querySelector('.diet-card-description').textContent.toLowerCase();
                        if (title.includes(term) || description.includes(term)) {
                            card.style.display = 'block';
                        } else {
                            card.style.display = 'none';
                        }
                    });
                });
            }
        });
    </script>
@endpush