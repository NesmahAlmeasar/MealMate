@extends('layouts.admin_app')

{{-- 1. تحديد عنوان الصفحة --}}
@section('title', 'User Management')

{{-- 2. إضافة ملف الـ CSS الخاص بالجدول --}}
@push('styles')
    <link rel="stylesheet" href="{{ asset('css/users.css') }}">
    
    {{-- =============================================== --}}
    {{-- ⭐️ 2. (تمت الإضافة) CSS الخاص بالمودال (Modal) ⭐️ --}}
    {{-- =============================================== --}}
    <style>
        .modal-overlay {
            display: none;
            position: fixed;
            z-index: 1000;
            left: 0;
            top: 0;
            width: 100%;
            height: 100%;
            overflow: auto;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            align-items: center;
            justify-content: center;
            animation: fadeIn 0.3s ease;
        }
        .modal-content {
            background-color: #fefefe;
            margin: auto;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.2);
            width: 90%;
            max-width: 600px;
            animation: slideIn 0.3s ease-out;
        }
        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            border-bottom: 1px solid var(--border-color, #E5E7EB);
            padding-bottom: 15px;
            margin-bottom: 20px;
        }
        .modal-title {
            font-size: 20px;
            font-weight: 600;
            color: var(--text-dark, #1F2937);
        }
        .modal-close {
            color: #aaa;
            font-size: 28px;
            font-weight: bold;
            cursor: pointer;
            transition: color 0.2s;
        }
        .modal-close:hover { color: #333; }
        .modal-body .form-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        .modal-body .form-group {
            display: flex;
            flex-direction: column;
            gap: 5px;
        }
        .modal-body .form-group.full-width {
            grid-column: 1 / -1;
        }
        .modal-body label {
            font-weight: 600;
            color: #1F2937;
            font-size: 14px;
        }
        .modal-body input[type="text"],
        .modal-body input[type="email"],
        .modal-body input[type="tel"],
        .modal-body input[type="password"],
        .modal-body input[type="file"],
        .modal-body select {
            width: 100%;
            padding: 10px 12px;
            border: 1px solid var(--border-color, #E5E7EB);
            border-radius: 8px;
            font-size: 14px;
            background-color: #f9f9f9;
            transition: all 0.3s ease;
        }
        .modal-body input:focus,
        .modal-body select:focus {
            outline: none;
            border-color: var(--olive-dark, #6B8E23);
            box-shadow: 0 0 0 2px rgba(107, 142, 35, 0.1);
        }
        .modal-footer {
            display: flex;
            justify-content: flex-end;
            gap: 10px;
            margin-top: 25px;
            padding-top: 15px;
            border-top: 1px solid var(--border-color, #E5E7EB);
        }
        .btn-secondary {
            background-color: #f3f4f6;
            color: #333;
            padding: 10px 15px;
            border-radius: 8px;
            border: 1px solid #ddd;
            cursor: pointer;
            font-weight: 600;
        }
        .btn-primary {
            background-color: var(--olive-dark, #6B8E23);
            color: white;
            padding: 10px 15px;
            border-radius: 8px;
            border: none;
            cursor: pointer;
            font-weight: 600;
        }
        
        /* ستايل رسائل الخطأ والنجاح */
        .alert {
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 8px;
            font-size: 14px;
        }
        .alert-success {
            color: #155724;
            background-color: #d4edda;
            border: 1px solid #c3e6cb;
        }
        .alert-danger {
            color: #721c24;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
        }
        .alert-danger ul {
            margin: 0;
            padding-left: 20px;
        }
        .form-group .invalid-feedback {
            color: var(--red-accent, #DC2626);
            font-size: 12px;
            margin-top: 4px;
        }
        .form-group input.is-invalid,
        .form-group select.is-invalid {
            border-color: var(--red-accent, #DC2626) !important;
            background-color: #FFF1F2;
        }
        
        /* ⭐️ (جديد) ستايل لحقل كلمة المرور الصحيح ⭐️ */
        .form-group input.is-valid {
            border-color: var(--green-accent, #10B981) !important;
            background-color: #F0FFF4;
        }
        
        @keyframes fadeIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes slideIn { from { transform: translateY(-30px); opacity: 0; } to { transform: translateY(0); opacity: 1; } }
    </style>
@endpush


{{-- 3. هذا هو المحتوى المتغير (الجدول) --}}
@section('content')
    <div class="users-section">
        <div class="section-header">
            <h1 class="section-title" data-i18n="userManagement">Diet Client Management</h1>
            <button class="btn-primary add-user-btn" id="openAddUserModal">
                <i class="fas fa-user-plus"></i>
                <span data-i18n="addNewClient">Add New Client</span>
            </button>
        </div>

        {{-- 4. مكان عرض رسائل النجاح أو الأخطاء --}}
        @if (session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        
        @if ($errors->any())
            <div class="alert alert-danger">
                <strong>حدث خطأ!</strong> الرجاء مراجعة الأخطاء في الفورم:
                <ul>
                    @foreach ($errors->all() as $error)
                        <li>{{ $error }}</li>
                    @endforeach
                </ul>
            </div>
        @endif
<div class="card users-table-card">
    <table class="users-table">
        {{-- ⭐️⭐️ رأس الجدول: 6 أعمدة كما في التصميم الأصلي ⭐️⭐️ --}}
        <thead>
            <tr>
                <th style="width: 50px;">Photo</th>
                <th>Full Name</th>               
                <th>Email</th>              
                <th>Phone</th>              
                <th>Role</th>               
                <th style="width: 120px;">Actions</th> 
            </tr>
        </thead>
        <tbody>
            @if ($users->isNotEmpty())
                @foreach ($users as $user)
                <tr class="user-row">
                    {{-- 1. الصورة --}}
                    <td data-label="الصورة">
                        @if ($user->photo_url)
                            <img src="{{ asset('storage/' . $user->photo_url) }}" alt="{{ $user->Fname }}" class="client-avatar">
                        @else
                            <div class="client-avatar" style="background: #ccc; text-align: center;">{{ substr($user->Fname, 0, 1) }}</div>
                        @endif
                    </td>
                    
                    {{-- 2. الاسم الكامل (Fname + Lname) --}}
                    <td data-label="اسم العميل">
                        <a href="{{ url('admin/users/profile/' . $user->user_id) }}" class="client-name-link">{{ $user->Fname }} {{ $user->Lname }}</a>
                    </td>
                    
                    {{-- 3. البريد الإلكتروني (Email) --}}
                    <td data-label="البريد الإلكتروني">
                        {{ $user->email }}
                    </td>
                    
                    {{-- 4. الهاتف (Phone) --}}
                    <td data-label="الهاتف">
                        {{ $user->phone }}
                    </td>
                    
                    {{-- 5. الدور (Role) --}}
                    <td data-label="Role">
                        @if ($user->roles->isNotEmpty())
                            @php $roleName = $user->roles->first()->name; @endphp
                            <span class="diet-tag diet-{{ strtolower($roleName) }}">{{ $roleName }}</span>
                        @else
                            <span class="diet-tag diet-client">عميل</span>
                        @endif
                    </td>
                    
                    {{-- 6. الإجراءات (Actions) --}}
                    <td data-label="الإجراءات">
                        <a href="{{ url('admin/messages?user=' . $user->user_id) }}" class="action-btn message-btn" title="Message Client"><i class="fas fa-envelope"></i></a>
                        <a href="{{ url('admin/users/edit/' . $user->user_id) }}" class="action-btn edit-btn" title="Edit Client Data"><i class="fas fa-edit"></i></a>
                        <button class="action-btn delete-btn" title="Delete Client" data-user-id="{{ $user->user_id }}"><i class="fas fa-trash"></i></button>
                    </td>
                </tr>
                @endforeach
            @else
                <tr class="user-row"><td colspan="6" style="text-align: center; padding: 20px;">لم يتم إضافة أي مستخدمين بعد.</td></tr>
            @endif
        </tbody>
    </table>
</div>
    {{-- 5. كود الـ HTML الخاص بالمودال --}}
    <div id="addUserModal" class="modal-overlay" style="display: {{ $errors->any() ? 'flex' : 'none' }};">
        <div class="modal-content">
            
            <div class="modal-header">
                <h2 class="modal-title">إضافة مستخدم جديد</h2>
                <span class="modal-close" id="closeAddUserModal">&times;</span>
            </div>

            <form action="{{ route('admin.users.store') }}" method="POST" enctype="multipart/form-data">
                @csrf
                
                <div class="modal-body">
                    <div class="form-grid">
                        
                        {{-- الحقل: Name (مع عرض الخطأ) --}}
                       <div class="form-group">
                            <label for="Fname">الاسم الأول (First Name)</label>
                            <input type="text" id="Fname" name="Fname" value="{{ old('Fname') }}" required 
                                   class="@error('Fname') is-invalid @enderror">
                            @error('Fname')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        <div class="form-group">
                            <label for="Lname">الاسم الأخير (Last Name)</label>
                            <input type="text" id="Lname" name="Lname" value="{{ old('Lname') }}" required 
                                   class="@error('Lname') is-invalid @enderror">
                            @error('Lname')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        {{-- الحقل: Email (مع عرض الخطأ) --}}
                        <div class="form-group">
                            <label for="email">البريد الإلكتروني (Email)</label>
                            <input type="email" id="email" name="email" value="{{ old('email') }}" required
                                   class="@error('email') is-invalid @enderror">
                            @error('email')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        {{-- الحقل: Phone (مع عرض الخطأ) --}}
                        <div class="form-group">
                            <label for="phone">الهاتف (Phone)</label>
                            <input type="tel" id="phone" name="phone" value="{{ old('phone') }}"
                                   class="@error('phone') is-invalid @enderror">
                            @error('phone')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        {{-- الحقل: Role (مع عرض الخطأ) --}}
                       {{-- الحقل: Role (مع عرض الخطأ) --}}
<div class="form-group">
    <label for="role_name">الدور (Role)</label>
    {{-- ⭐️⭐️ تغيير name="role" إلى name="role_name" ⭐️⭐️ --}}
    <select id="role_name" name="role_name" class="@error('role_name') is-invalid @enderror">
        <option value="Client" {{ old('role_name') == 'Client' ? 'selected' : '' }}>عميل (Client)</option>
        <option value="Specialist" {{ old('role_name') == 'Specialist' ? 'selected' : '' }}>أخصائي (Specialist)</option>
        <option value="Admin" {{ old('role_name') == 'Admin' ? 'selected' : '' }}>مدير (Admin)</option>
    </select>
    {{-- ⭐️⭐️ تغيير @error('role') إلى @error('role_name') ⭐️⭐️ --}}
    @error('role_name')
        <div class="invalid-feedback">{{ $message }}</div>
    @enderror
</div>
                        
                        {{-- الحقل: Password (مع عرض الخطأ) --}}
                        <div class="form-group">
                            <label for="password">كلمة المرور (Password)</label>
                            <input type="password" id="password" name="password" required
                                   class="@error('password') is-invalid @enderror">
                            @error('password')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        {{-- الحقل: Password Confirmation --}}
                        <div class="form-group">
                            <label for="password_confirmation">تأكيد كلمة المرور</label>
                            <input type="password" id="password_confirmation" name="password_confirmation" required>
                        </div>

                        {{-- الحقل: Photo (مع عرض الخطأ) --}}
                        <div class="form-group full-width">
                            <label for="photo">الصورة (Photo)</label>
                            <input type="file" id="photo" name="photo" class="@error('photo') is-invalid @enderror">
                            @error('photo')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                        
                        {{-- الحقل: Account State (مع عرض الخطأ) --}}
                        <div class="form-group full-width">
                            <label for="account_state">حالة الحساب (Account State)</label>
                            <select id="account_state" name="account_state" class="@error('account_state') is-invalid @enderror">
                                <option value="Active" {{ old('account_state', 'Active') == 'Active' ? 'selected' : '' }}>نشط (Active)</option>
                                <option value="Pending" {{ old('account_state') == 'Pending' ? 'selected' : '' }}>قيد الانتظار (Pending)</option>
                                <option value="Banned" {{ old('account_state') == 'Banned' ? 'selected' : '' }}>محظور (Banned)</option>
                            </select>
                            @error('account_state')
                                <div class="invalid-feedback">{{ $message }}</div>
                            @enderror
                        </div>
                    </div>
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn-secondary" id="cancelAddUserModal">إلغاء</button>
                    <button type="submit" class="btn-primary">حفظ المستخدم</button>
                </div>
            </form>

        </div>
    </div>

    <form id="delete-form" method="POST" style="display: none;">
    @csrf
    @method('DELETE') </form>

@endsection


{{-- 5. JS الخاص بفتح وإغلاق المودال --}}
@push('scripts')
    <script>


// ... (داخل دالة document.addEventListener('DOMContentLoaded', function() { ... )

// --- كود معالجة الحذف ---
document.querySelectorAll('.delete-btn').forEach(button => {
    button.addEventListener('click', function() {
        const userId = this.getAttribute('data-user-id');
        const confirmation = confirm('هل أنت متأكد من أنك تريد حذف هذا المستخدم؟');

        if (confirmation) {
            const deleteForm = document.getElementById('delete-form');
            // 💡 تحديث رابط الـ Form ليطابق المسار: admin/users/{id}
            deleteForm.action = '{{ url('admin/users') }}/' + userId; 
            deleteForm.submit();
        }
    });
});

        document.addEventListener('DOMContentLoaded', function() {
            // --- كود فتح وإغلاق المودال ---
            const modal = document.getElementById('addUserModal');
            const openBtn = document.getElementById('openAddUserModal');
            const closeBtn = document.getElementById('closeAddUserModal');
            const cancelBtn = document.getElementById('cancelAddUserModal');

            function openModal() { if (modal) modal.style.display = 'flex'; }
            function closeModal() { if (modal) modal.style.display = 'none'; }

            if(openBtn) openBtn.addEventListener('click', openModal);
            if(closeBtn) closeBtn.addEventListener('click', closeModal);
            if(cancelBtn) cancelBtn.addEventListener('click', closeModal);

            if (modal) {
                modal.addEventListener('click', function(event) {
                    if (event.target === modal) { closeModal(); }
                });
            }

            // ===============================================
            // ⭐️ (جديد) كود مطابقة كلمة المرور (JavaScript) ⭐️
            // ===============================================
            const passwordField = document.getElementById('password');
            const confirmPasswordField = document.getElementById('password_confirmation');

            function validatePasswordMatch() {
                // (يجب أن تكون أطول من 7 حروف لتجنب الخطأ من 'min:8')
                if (passwordField.value.length > 7 && passwordField.value === confirmPasswordField.value) {
                    // إذا تطابقت
                    confirmPasswordField.classList.remove('is-invalid');
                    confirmPasswordField.classList.add('is-valid');
                } else if (confirmPasswordField.value.length > 0) {
                    // إذا لم تتطابق
                    confirmPasswordField.classList.remove('is-valid');
                    confirmPasswordField.classList.add('is-invalid');
                } else {
                    // إذا كانت فارغة
                    confirmPasswordField.classList.remove('is-valid');
                    confirmPasswordField.classList.remove('is-invalid');
                }
            }

            if (passwordField && confirmPasswordField) {
                // استدعاء الدالة عند الكتابة في أي من الحقلين
                passwordField.addEventListener('keyup', validatePasswordMatch);
                confirmPasswordField.addEventListener('keyup', validatePasswordMatch);
            }
        });
    </script>
@endpush